import 'package:flutter/material.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  void _mensaje(String message) {
    final snackBar = SnackBar(
      content: Text(message),
      action: SnackBarAction(
        label: 'Undo',
        onPressed: () {},
      ),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        backgroundColor: Colors.white,
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              const DrawerHeader(
                decoration: BoxDecoration(color: Colors.green),
                child: Text("WhatsApp Menu", style: TextStyle(color: Colors.white)),
              ),
              ListTile(
                title: const Text('New Group'),
                onTap: () {
                  _mensaje("New Group selected");
                },
              ),
              ListTile(
                title: const Text('Settings'),
                onTap: () {
                  _mensaje("Settings selected");
                },
              ),
            ],
          ),
        ),
        appBar: AppBar(
          title: const Text("WhatsApp"),
          backgroundColor: Colors.green,
          bottom: const TabBar(
            indicatorColor: Colors.white,
            tabs: [
              Tab(icon: Icon(Icons.camera_alt)),
              Tab(text: 'CHATS'),
              Tab(text: 'STATUS'),
              Tab(text: 'CALLS'),
            ],
          ),
        ),
        body: TabBarView(
          children: <Widget>[
            Center(
              child: Text("Camara"), 
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: ListView(
                children: <Widget>[
                  ListTile(
                    leading: CircleAvatar(backgroundColor: const Color.fromARGB(255, 209, 126, 126)),
                    title: Text('Arya Stark'),
                    subtitle: Text('I wish GoT had better ending...'),
                    trailing: Text('Yesterday'),
                  ),
                  ListTile(
                    leading: CircleAvatar(backgroundColor: Colors.red),
                    title: Text('Robb Stark'),
                    subtitle: Text("Did you check Maisie's status?"),
                    trailing: Text('Yesterday'),
                  ),
                  ListTile(
                    leading: CircleAvatar(backgroundColor: Colors.grey),
                    title: Text('Jaqen H'),
                    subtitle: Text("Valar Morghulis"),
                    trailing: Text('Yesterday'),
                  ),
                  ListTile(
                    leading: CircleAvatar(backgroundColor: Colors.yellow),
                    title: Text('Sansa Stark'),
                    subtitle: Text("The North Remembers"),
                    trailing: Text('Yesterday'),
                  ),
                  ListTile(
                    leading: CircleAvatar(backgroundColor: Colors.grey),
                    title: Text('Jon Snow'),
                    subtitle: Text("Stick em' with the point......"),
                    trailing: Text('Yesterday'),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: ListView(
                children: <Widget>[
                  ListTile(
                    leading: CircleAvatar(backgroundColor: Colors.green, child: Icon(Icons.add, color: Colors.white)),
                    title: Text('My Status'),
                    subtitle: Text('Tap to add status'),
                    onTap: () {
                      _mensaje("Add new status");
                    },
                  ),
                  Divider(),
                  ListTile(
                    leading: CircleAvatar(backgroundColor: Colors.grey),
                    title: Text('Arya Stark'),
                    subtitle: Text("7 minutes ago"),
                    onTap: () {
                      _mensaje("Viewing Arya Stark's status");
                    },
                  ),
                ],
              ),
            ),
            const Center(
              child: Text("No recent calls"),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            _mensaje("New chat");
          },
          backgroundColor: Colors.green,
          child: const Icon(Icons.chat),
        ),
      ),
    );
  }
}

